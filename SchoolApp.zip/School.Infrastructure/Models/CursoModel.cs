﻿namespace School.Infrastructure.Models
{
    public class CursoModel
    {
        public string Name { get; set; }
        public string Code { get; set; }
    }
}
