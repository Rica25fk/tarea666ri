﻿namespace School.Infrastructure.Models
{
    public class DepartmentModel
    {
        public string Name { get; set; }
    }
}
