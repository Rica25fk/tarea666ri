﻿namespace School.Infrastructure.Exceptions
{
    public class CourseException : Exception
    {
        public CourseException(string message) : base(message) { }
    }
}
